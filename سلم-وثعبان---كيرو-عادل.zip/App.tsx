import React, { useState, useEffect, useCallback } from 'react';
import { Player, GameStatus, SnakeOrLadder, GameMode, Difficulty, BasePlayerConfig } from './types';
import { BOARD_SIZE, WINNING_POSITION, BASE_PLAYER_CONFIGS, COMPUTER_PLAYER_BASE_CONFIG_INDEX, SNAKES_AND_LADDERS, MAX_PLAYERS, DIFFICULTY_MAP } from './constants';
import Board from './components/Board';
import Dice from './components/Dice';
import GameInfo from './components/GameInfo';
import Modal from './components/Modal';

const App: React.FC = () => {
  const [players, setPlayers] = useState<Player[]>([]);
  const [currentPlayerIndex, setCurrentPlayerIndex] = useState<number>(0);
  const [diceValue, setDiceValue] = useState<number | null>(null);
  const [gameStatus, setGameStatus] = useState<GameStatus>(GameStatus.SETUP);
  const [winner, setWinner] = useState<Player | null>(null);
  const [message, setMessage] = useState<string>('قم بإعداد لعبتك للبدء!');
  const [isRolling, setIsRolling] = useState<boolean>(false);

  // Setup screen state
  const [selectedGameMode, setSelectedGameMode] = useState<GameMode>(GameMode.PVP);
  const [selectedNumPlayers, setSelectedNumPlayers] = useState<number>(2);
  const [selectedDifficulty, setSelectedDifficulty] = useState<Difficulty>(Difficulty.EASY);

  const resetGameToSetup = useCallback(() => {
    setPlayers([]);
    setCurrentPlayerIndex(0);
    setDiceValue(null);
    setGameStatus(GameStatus.SETUP);
    setWinner(null);
    setMessage('قم بإعداد لعبتك للبدء!');
    setIsRolling(false);
    // Reset setup options to default or last used, for now default
    setSelectedGameMode(GameMode.PVP);
    setSelectedNumPlayers(2);
    setSelectedDifficulty(Difficulty.EASY);
  }, []);
  
  useEffect(() => {
    if (gameStatus === GameStatus.PLAYING && winner) {
      setGameStatus(GameStatus.GAME_OVER);
      setMessage(`🎉 ${winner.name} هو الفائز! 🎉`);
    }
  }, [winner, gameStatus]);

  const handleStartGame = () => {
    const newPlayers: Player[] = [];
    if (selectedGameMode === GameMode.PVP) {
      for (let i = 0; i < selectedNumPlayers; i++) {
        const config = BASE_PLAYER_CONFIGS[i % BASE_PLAYER_CONFIGS.length];
        newPlayers.push({
          id: i + 1,
          name: `لاعب ${i + 1}`,
          position: 1,
          color: config.color,
          textColor: config.textColor,
          isComputer: false,
        });
      }
    } else { // GameMode.PVC
      const humanConfig = BASE_PLAYER_CONFIGS[0];
      newPlayers.push({
        id: 1,
        name: 'أنت',
        position: 1,
        color: humanConfig.color,
        textColor: humanConfig.textColor,
        isComputer: false,
      });
      const computerConfig = BASE_PLAYER_CONFIGS[COMPUTER_PLAYER_BASE_CONFIG_INDEX % BASE_PLAYER_CONFIGS.length];
      newPlayers.push({
        id: 2,
        name: `كمبيوتر (${DIFFICULTY_MAP[selectedDifficulty]})`,
        position: 1,
        color: computerConfig.color,
        textColor: computerConfig.textColor,
        isComputer: true,
      });
    }
    setPlayers(newPlayers);
    setCurrentPlayerIndex(0);
    setDiceValue(null);
    setWinner(null);
    setGameStatus(GameStatus.PLAYING);
    setMessage(`بدأت اللعبة! ${newPlayers[0].name}, قم برمي النرد.`);
  };
  

  const handleDiceRollLogic = useCallback(() => {
    const roll = Math.floor(Math.random() * 6) + 1;
    setDiceValue(roll);
    
    const currentPlayer = players[currentPlayerIndex];
    let newPosition = currentPlayer.position + roll;
    let moveMessage = `${currentPlayer.name} رمى ${roll}.`;

    if (newPosition > WINNING_POSITION) {
      newPosition = currentPlayer.position; 
      moveMessage += ` تجاوز ${WINNING_POSITION}، يبقى في مكانه.`;
    } else if (newPosition === WINNING_POSITION) {
      moveMessage += ` وصل إلى ${WINNING_POSITION}!`;
      setWinner(currentPlayer); // Set winner immediately
    }

    const snakeOrLadder = SNAKES_AND_LADDERS.find(sl => sl.start === newPosition);
    if (snakeOrLadder && newPosition !== WINNING_POSITION && !winner) {
      const prevPos = newPosition;
      newPosition = snakeOrLadder.end;
      if (snakeOrLadder.type === 'snake') {
        moveMessage += ` 🐍 يا للأسف! من ${prevPos} انزلق إلى ${newPosition}.`;
      } else {
        moveMessage += ` 🪜 رائع! من ${prevPos} صعد إلى ${newPosition}.`;
      }
      if (newPosition === WINNING_POSITION && !winner) { // Check win after snake/ladder
         setWinner(currentPlayer);
         moveMessage += ` وصل إلى ${WINNING_POSITION}!`;
      }
    }
    
    const updatedPlayers = players.map((p, index) =>
      index === currentPlayerIndex ? { ...p, position: newPosition } : p
    );
    setPlayers(updatedPlayers);
    
    // Check for winner again after position update, though it should be caught above
    const potentialWinner = updatedPlayers[currentPlayerIndex];
    if (potentialWinner.position === WINNING_POSITION && !winner) {
        setWinner(potentialWinner);
    }

    setTimeout(() => {
      setMessage(moveMessage);
      // Only switch player if game is not over
      if (potentialWinner.position !== WINNING_POSITION && !winner) {
        setCurrentPlayerIndex((prevIndex) => (prevIndex + 1) % updatedPlayers.length);
      }
      setIsRolling(false);
    }, 500);

  }, [players, currentPlayerIndex, winner]); // Removed gameStatus from deps as it's handled by winner

  const handleHumanDiceRoll = useCallback(() => {
    if (isRolling || gameStatus !== GameStatus.PLAYING || players[currentPlayerIndex]?.isComputer || winner) return;
    setIsRolling(true);
    handleDiceRollLogic();
  }, [isRolling, gameStatus, players, currentPlayerIndex, winner, handleDiceRollLogic]);


  useEffect(() => {
    if (
      gameStatus === GameStatus.PLAYING &&
      players.length > 0 &&
      players[currentPlayerIndex]?.isComputer &&
      !isRolling &&
      !winner
    ) {
      setIsRolling(true); // Indicate computer is "rolling"
      setMessage(`${players[currentPlayerIndex].name} يفكر...`);
      setTimeout(() => {
        // AI Difficulty logic can be expanded here. For now, it's random.
        // Easy: Pure random (current implementation)
        // Medium: (Future) Maybe slight bias to avoid own snakes or hit own ladders
        // Hard: (Future) Stronger bias or "lucky" rolls
        handleDiceRollLogic();
      }, 1500 + Math.random() * 1000); // Add some variability to computer's "thinking" time
    }
  }, [gameStatus, players, currentPlayerIndex, isRolling, winner, handleDiceRollLogic, selectedDifficulty]);


  if (gameStatus === GameStatus.SETUP) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-4 bg-gradient-to-br from-sky-400 via-cyan-500 to-blue-600 text-white">
        <div className="bg-white/90 backdrop-blur-md shadow-2xl rounded-xl p-8 w-full max-w-lg space-y-6">
          <h1 className="text-4xl font-bold text-center text-slate-800" style={{fontFamily: "'Cairo', sans-serif"}}>إعداد لعبة سلم وثعبان</h1>
          
          {/* Game Mode Selection */}
          <div className="space-y-2">
            <label className="block text-lg font-medium text-slate-700">نمط اللعب:</label>
            <div className="flex space-x-4 rtl:space-x-reverse">
              {(Object.keys(GameMode) as Array<keyof typeof GameMode>).map((modeKey) => (
                <button
                  key={modeKey}
                  onClick={() => setSelectedGameMode(GameMode[modeKey])}
                  className={`flex-1 py-2 px-4 rounded-md transition-colors ${selectedGameMode === GameMode[modeKey] ? 'bg-indigo-600 text-white' : 'bg-slate-200 text-slate-700 hover:bg-slate-300'}`}
                >
                  {GameMode[modeKey] === GameMode.PVP ? 'لاعب ضد لاعب' : 'لاعب ضد الكمبيوتر'}
                </button>
              ))}
            </div>
          </div>

          {/* Number of Players (for PVP) */}
          {selectedGameMode === GameMode.PVP && (
            <div className="space-y-2">
              <label htmlFor="numPlayers" className="block text-lg font-medium text-slate-700">عدد اللاعبين:</label>
              <select
                id="numPlayers"
                value={selectedNumPlayers}
                onChange={(e) => setSelectedNumPlayers(parseInt(e.target.value))}
                className="w-full p-2 border border-slate-300 rounded-md text-slate-700 focus:ring-indigo-500 focus:border-indigo-500"
              >
                {[2, 3, 4].map(num => (
                  <option key={num} value={num}>{num}</option>
                ))}
              </select>
            </div>
          )}

          {/* Difficulty (for PVC) */}
          {selectedGameMode === GameMode.PVC && (
            <div className="space-y-2">
              <label htmlFor="difficulty" className="block text-lg font-medium text-slate-700">مستوى الصعوبة:</label>
              <select
                id="difficulty"
                value={selectedDifficulty}
                onChange={(e) => setSelectedDifficulty(e.target.value as Difficulty)}
                className="w-full p-2 border border-slate-300 rounded-md text-slate-700 focus:ring-indigo-500 focus:border-indigo-500"
              >
                {(Object.keys(Difficulty) as Array<keyof typeof Difficulty>).map((diffKey) => (
                  <option key={diffKey} value={Difficulty[diffKey]}>{DIFFICULTY_MAP[Difficulty[diffKey]]}</option>
                ))}
              </select>
            </div>
          )}

          <button
            onClick={handleStartGame}
            className="w-full bg-green-500 hover:bg-green-600 text-white font-bold py-3 px-4 rounded-lg shadow-md transition duration-150 ease-in-out transform hover:scale-105"
          >
            ابدأ اللعبة
          </button>
        </div>
        <footer className="mt-8 text-center text-sky-100 text-sm">
          <p>&copy; {new Date().getFullYear()} تطوير كيرو عادل. جميع الحقوق محفوظة.</p>
        </footer>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4 bg-gradient-to-br from-teal-400 via-blue-500 to-indigo-600 text-white">
      <header className="mb-8 text-center">
        <h1 className="text-5xl font-bold tracking-tight" style={{fontFamily: "'Cairo', sans-serif"}}>سلم وثعبان - كيرو عادل</h1>
        <p className="text-xl text-indigo-100 mt-2">
          {selectedGameMode === GameMode.PVP ? `${selectedNumPlayers} لاعبين` : `لاعب ضد كمبيوتر (${DIFFICULTY_MAP[selectedDifficulty]})`}
        </p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 w-full max-w-6xl">
        <div className="md:col-span-2 bg-white/90 backdrop-blur-md shadow-2xl rounded-xl p-2 sm:p-4">
          <Board players={players} snakesAndLadders={SNAKES_AND_LADDERS} />
        </div>
        
        <div className="bg-white/90 backdrop-blur-md shadow-2xl rounded-xl p-6 flex flex-col justify-between space-y-6">
          {players.length > 0 && (
            <GameInfo
              currentPlayerName={players[currentPlayerIndex]?.name || ''}
              currentPlayerColor={players[currentPlayerIndex]?.textColor || ''}
              diceValue={diceValue}
              message={message}
              gameStatus={gameStatus}
            />
          )}
          <Dice 
            onRoll={handleHumanDiceRoll} 
            diceValue={diceValue} 
            disabled={isRolling || gameStatus === GameStatus.GAME_OVER || players[currentPlayerIndex]?.isComputer || !!winner} 
            isRolling={isRolling && (!players[currentPlayerIndex]?.isComputer || gameStatus !== GameStatus.PLAYING)} // Show rolling animation for human, or if computer is "thinking"
          />
          <button
            onClick={resetGameToSetup}
            className="w-full bg-yellow-500 hover:bg-yellow-600 text-black font-bold py-3 px-4 rounded-lg shadow-md transition duration-150 ease-in-out transform hover:scale-105"
          >
            إعدادات اللعبة / إعادة
          </button>
        </div>
      </div>

      {gameStatus === GameStatus.GAME_OVER && winner && (
        <Modal isOpen={true} onClose={resetGameToSetup} title="انتهت اللعبة!">
          <p className="text-2xl font-semibold text-center text-gray-700">{`🎉 ${winner.name} هو الفائز! 🎉`}</p>
          <img src={`https://picsum.photos/seed/${winner.id + winner.name}/300/200`} alt="Celebration" className="mt-4 rounded-lg mx-auto" />
          <button
            onClick={resetGameToSetup}
            className="mt-6 w-full bg-green-500 hover:bg-green-600 text-white font-bold py-3 px-4 rounded-lg shadow-md transition duration-150 ease-in-out"
          >
            العب مرة أخرى
          </button>
        </Modal>
      )}
       <footer className="mt-8 text-center text-indigo-200 text-sm">
        <p>&copy; {new Date().getFullYear()} تطوير كيرو عادل. جميع الحقوق محفوظة.</p>
      </footer>
    </div>
  );
};

export default App;
