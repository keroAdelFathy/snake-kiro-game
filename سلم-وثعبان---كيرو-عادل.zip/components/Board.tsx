
import React from 'react';
import { Player, SnakeOrLadder } from '../types';
import { NUM_ROWS, NUM_COLS } from '../constants';
import PlayerToken from './PlayerToken';

interface BoardProps {
  players: Player[];
  snakesAndLadders: SnakeOrLadder[];
}

const Board: React.FC<BoardProps> = ({ players, snakesAndLadders }) => {
  const cells = [];

  const getCellNumber = (visualRow: number, visualCol: number): number => {
    const actualRowFromBottom = NUM_ROWS - 1 - visualRow; // 0-indexed from bottom
    let cellNumber: number;
    if (actualRowFromBottom % 2 === 0) { // Even rows (0, 2, ... from bottom) go L-R
      cellNumber = actualRowFromBottom * NUM_COLS + visualCol + 1;
    } else { // Odd rows (1, 3, ... from bottom) go R-L
      cellNumber = actualRowFromBottom * NUM_COLS + (NUM_COLS - 1 - visualCol) + 1;
    }
    return cellNumber;
  };

  for (let i = 0; i < NUM_ROWS; i++) { // visualRow
    for (let j = 0; j < NUM_COLS; j++) { // visualCol
      const cellNumber = getCellNumber(i, j);
      const playersOnCell = players.filter(p => p.position === cellNumber);
      
      let cellBgColor = (i + j) % 2 === 0 ? 'bg-emerald-50' : 'bg-teal-50';
      let specialContent = null;
      let borderColor = 'border-slate-200';

      const slEntity = snakesAndLadders.find(sl => sl.start === cellNumber || sl.end === cellNumber);
      if (slEntity) {
        if (slEntity.start === cellNumber) {
          borderColor = slEntity.type === 'snake' ? 'border-red-400' : 'border-green-400';
          cellBgColor = slEntity.type === 'snake' ? 'bg-red-200' : 'bg-green-200';
          specialContent = (
            <span className="absolute top-0.5 right-0.5 text-xl">
              {slEntity.type === 'snake' ? '🐍' : '🪜'}
            </span>
          );
        } else { // end of snake/ladder
           cellBgColor = slEntity.type === 'snake' ? 'bg-red-100' : 'bg-green-100';
           borderColor = slEntity.type === 'snake' ? 'border-red-300' : 'border-green-300';
        }
      }
      
      if (cellNumber === 1) cellBgColor = 'bg-yellow-200';
      if (cellNumber === 100) cellBgColor = 'bg-amber-300';

      cells.push(
        <div
          key={cellNumber}
          className={`relative aspect-square border ${borderColor} ${cellBgColor} flex flex-col items-center justify-center p-1 text-xs sm:text-sm font-medium text-slate-700`}
        >
          <span className="absolute top-1 left-1 opacity-70">{cellNumber}</span>
          {specialContent}
          <div className="flex flex-wrap justify-center items-end gap-0.5 z-10 mt-2">
            {playersOnCell.map(player => (
              <PlayerToken key={player.id} color={player.color} playerId={player.id} />
            ))}
          </div>
        </div>
      );
    }
  }

  return (
    <div className="grid grid-cols-10 grid-rows-10 border-4 border-slate-300 rounded-lg overflow-hidden shadow-lg aspect-square mx-auto max-w-full w-[calc(100vh-250px)] sm:w-[calc(100vh-200px)] md:w-auto md:max-h-[calc(100vh-150px)] md:max-w-2xl">
      {cells}
    </div>
  );
};

export default Board;
