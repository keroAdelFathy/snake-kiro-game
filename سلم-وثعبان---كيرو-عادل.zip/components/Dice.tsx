
import React, { useState, useEffect } from 'react';

interface DiceProps {
  onRoll: () => void;
  diceValue: number | null;
  disabled: boolean;
  isRolling: boolean;
}

const DiceFace: React.FC<{ value: number }> = ({ value }) => {
  const dots = [];
  const dotPositions: { [key: number]: string[] } = {
    1: ['center'],
    2: ['top-left', 'bottom-right'],
    3: ['top-left', 'center', 'bottom-right'],
    4: ['top-left', 'top-right', 'bottom-left', 'bottom-right'],
    5: ['top-left', 'top-right', 'center', 'bottom-left', 'bottom-right'],
    6: ['top-left', 'top-right', 'middle-left', 'middle-right', 'bottom-left', 'bottom-right'],
  };

  const getDotClass = (pos: string) => {
    let classes = 'w-3 h-3 sm:w-4 sm:h-4 bg-slate-700 rounded-full absolute';
    if (pos === 'center') classes += ' top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2';
    if (pos === 'top-left') classes += ' top-2 left-2 sm:top-3 sm:left-3';
    if (pos === 'top-right') classes += ' top-2 right-2 sm:top-3 sm:right-3';
    if (pos === 'bottom-left') classes += ' bottom-2 left-2 sm:bottom-3 sm:left-3';
    if (pos === 'bottom-right') classes += ' bottom-2 right-2 sm:bottom-3 sm:right-3';
    if (pos === 'middle-left') classes += ' top-1/2 left-2 sm:left-3 -translate-y-1/2';
    if (pos === 'middle-right') classes += ' top-1/2 right-2 sm:right-3 -translate-y-1/2';
    return classes;
  };

  if (dotPositions[value]) {
    dotPositions[value].forEach(pos => {
      dots.push(<div key={pos} className={getDotClass(pos)}></div>);
    });
  }

  return (
    <div className="w-16 h-16 sm:w-20 sm:h-20 bg-white border-2 border-slate-300 rounded-lg shadow-md relative flex items-center justify-center">
      {dots}
    </div>
  );
};


const Dice: React.FC<DiceProps> = ({ onRoll, diceValue, disabled, isRolling }) => {
  const [displayValue, setDisplayValue] = useState<number>(1);

  useEffect(() => {
    if (isRolling) {
      let rollCount = 0;
      const interval = setInterval(() => {
        setDisplayValue(Math.floor(Math.random() * 6) + 1);
        rollCount++;
        if (rollCount > 10) { // Simulate rolling for a bit
          clearInterval(interval);
          if (diceValue !== null) setDisplayValue(diceValue);
        }
      }, 50); // Faster animation
      return () => clearInterval(interval);
    } else if (diceValue !== null) {
      setDisplayValue(diceValue);
    }
  }, [isRolling, diceValue]);


  return (
    <div className="flex flex-col items-center space-y-4">
      <DiceFace value={displayValue} />
      <button
        onClick={onRoll}
        disabled={disabled}
        className="w-full bg-indigo-500 hover:bg-indigo-600 text-white font-bold py-3 px-4 rounded-lg shadow-md transition duration-150 ease-in-out disabled:opacity-50 disabled:cursor-not-allowed transform hover:scale-105 focus:outline-none focus:ring-2 focus:ring-indigo-300"
      >
        {isRolling ? 'جارٍ الرمي...' : 'ارمي النرد'}
      </button>
    </div>
  );
};

export default Dice;
