import React from 'react';
import { GameStatus } from '../types';

interface GameInfoProps {
  currentPlayerName: string;
  currentPlayerColor: string;
  diceValue: number | null;
  message: string;
  gameStatus: GameStatus;
}

const GameInfo: React.FC<GameInfoProps> = ({ currentPlayerName, currentPlayerColor, diceValue, message, gameStatus }) => {
  return (
    <div className="text-center space-y-3 p-4 bg-slate-50 rounded-lg shadow text-gray-700 min-h-[150px] flex flex-col justify-center">
      <h2 className="text-2xl font-semibold text-indigo-700">معلومات اللعبة</h2>
      
      {gameStatus === GameStatus.PLAYING && currentPlayerName && (
        <p className="text-lg">
          الدور الحالي: <span className={`font-bold ${currentPlayerColor || 'text-gray-700'}`}>{currentPlayerName}</span>
        </p>
      )}
      
      {diceValue !== null && gameStatus === GameStatus.PLAYING && (
        <p className="text-lg">
          آخر رمية: <span className="font-bold text-xl text-indigo-600">{diceValue}</span>
        </p>
      )}
      
      <div className="mt-2 p-3 bg-indigo-100 rounded-md min-h-[60px] flex items-center justify-center">
        <p className="text-sm md:text-base text-indigo-800">{message}</p>
      </div>
    </div>
  );
};

export default GameInfo;
