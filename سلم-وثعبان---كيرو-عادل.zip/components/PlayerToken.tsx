
import React from 'react';

interface PlayerTokenProps {
  color: string;
  playerId: number;
}

const PlayerToken: React.FC<PlayerTokenProps> = ({ color, playerId }) => {
  return (
    <div
      className={`w-4 h-4 sm:w-5 sm:h-5 rounded-full ${color} border-2 border-white shadow-md flex items-center justify-center text-white text-xs font-bold`}
      title={`لاعب ${playerId}`}
    >
      {/* Optionally display player ID or initial: P{playerId} */}
    </div>
  );
};

export default PlayerToken;
