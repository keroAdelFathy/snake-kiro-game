
// Fix: Import Difficulty enum
import { SnakeOrLadder, BasePlayerConfig, Difficulty } from './types';

export const BOARD_SIZE = 100;
export const NUM_ROWS = 10;
export const NUM_COLS = 10;
export const WINNING_POSITION = 100;
export const MAX_PLAYERS = 4;

export const BASE_PLAYER_CONFIGS: BasePlayerConfig[] = [
  { defaultName: 'لاعب 1', color: 'bg-red-500', textColor: 'text-red-500' },
  { defaultName: 'لاعب 2', color: 'bg-blue-500', textColor: 'text-blue-500' },
  { defaultName: 'لاعب 3', color: 'bg-green-500', textColor: 'text-green-500' },
  { defaultName: 'لاعب 4', color: 'bg-yellow-500', textColor: 'text-yellow-500' },
];

// For Computer Player, we can use one of the base configs, e.g., the second one.
export const COMPUTER_PLAYER_BASE_CONFIG_INDEX = 1; // Uses BASE_PLAYER_CONFIGS[1] for computer

export const SNAKES_AND_LADDERS: SnakeOrLadder[] = [
  // Ladders
  { start: 1, end: 38, type: 'ladder' },
  { start: 4, end: 14, type: 'ladder' },
  { start: 9, end: 31, type: 'ladder' },
  { start: 21, end: 42, type: 'ladder' },
  { start: 28, end: 84, type: 'ladder' },
  { start: 51, end: 67, type: 'ladder' },
  { start: 72, end: 91, type: 'ladder' },
  { start: 80, end: WINNING_POSITION, type: 'ladder' },
  
  // Snakes
  { start: 17, end: 7, type: 'snake' },
  { start: 54, end: 34, type: 'snake' },
  { start: 62, end: 19, type: 'snake' },
  { start: 64, end: 60, type: 'snake' },
  { start: 87, end: 24, type: 'snake' },
  { start: 93, end: 73, type: 'snake' },
  { start: 95, end: 75, type: 'snake' },
  { start: 98, end: 78, type: 'snake' },
];

export const DIFFICULTY_MAP: { [key in Difficulty]: string } = {
  [Difficulty.EASY]: 'سهل',
  [Difficulty.MEDIUM]: 'متوسط',
  [Difficulty.HARD]: 'صعب',
};