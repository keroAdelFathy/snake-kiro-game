export interface Player {
  id: number;
  name: string; // This will be the final display name, e.g., "أنت", "كمبيوتر (سهل)", "لاعب 1"
  position: number;
  color: string;
  textColor: string;
  isComputer?: boolean;
}

export interface SnakeOrLadder {
  start: number;
  end: number;
  type: 'snake' | 'ladder';
}

export enum GameStatus {
  SETUP = 'SETUP',
  PLAYING = 'PLAYING',
  GAME_OVER = 'GAME_OVER',
}

export enum GameMode {
  PVP = 'PVP', // Player vs Player
  PVC = 'PVC', // Player vs Computer
}

export enum Difficulty {
  EASY = 'EASY',
  MEDIUM = 'MEDIUM',
  HARD = 'HARD',
}

export interface BasePlayerConfig {
  defaultName: string;
  color: string;
  textColor: string;
}
